package com.jarvis.ai

import android.Manifest
import android.animation.ValueAnimator
import android.app.AlertDialog
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class OrbView(c: Context) : View(c) {
    var active = false
    var level = 0f
    private var t = 0f
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy)
        val pulse = Math.sin(t * 2 * Math.PI).toFloat()
        val k = if (active) 0.06f + 0.1f * level else 0.03f
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r, intArrayOf(0x8800B4FF.toInt(), 0x2200B4FF, 0x00000000), floatArrayOf(0.3f, 0.7f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r * (0.9f + k * pulse), p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.color = 0xFF00D4FF.toInt()
        p.strokeWidth = 3f * d
        cv.drawCircle(cx, cy, r * 0.55f, p)
        p.strokeWidth = 5f * d
        rect.set(cx - r * 0.7f, cy - r * 0.7f, cx + r * 0.7f, cy + r * 0.7f)
        cv.drawArc(rect, t * 360f, 80f, false, p)
        cv.drawArc(rect, t * 360f + 180f, 80f, false, p)
        p.color = 0x6600D4FF
        rect.set(cx - r * 0.8f, cy - r * 0.8f, cx + r * 0.8f, cy + r * 0.8f)
        cv.drawArc(rect, -t * 540f, 50f, false, p)
        p.style = Paint.Style.FILL
        p.color = 0xFF08233F.toInt()
        cv.drawCircle(cx, cy, r * 0.48f, p)
        p.color = 0xFF00D4FF.toInt()
        cv.drawCircle(cx, cy, r * (0.14f + 0.03f * pulse + 0.1f * level), p)
    }
}

class MainActivity : Activity() {
    private val BG = 0xFF050B18.toInt()
    private val CYAN = 0xFF00D4FF.toInt()
    private val PANEL = 0xFF0C1A33.toInt()
    private val TEXT = 0xFFE6F3FF.toInt()
    private val DIM = 0xFF7FA3C7.toInt()
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private lateinit var p: Prefs
    private lateinit var speaker: Speaker
    private lateinit var brain: Brain
    private lateinit var orb: OrbView
    private lateinit var status: TextView
    private lateinit var clock: TextView
    private lateinit var reply: TextView
    private lateinit var heard: TextView
    private lateinit var remBox: LinearLayout
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            clock.text = SimpleDateFormat("hh:mm:ss a  •  EEE, d MMM", Locale.US).format(Date())
            h.postDelayed(this, 1000)
        }
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun tv(s: String, sz: Float, col: Int = TEXT, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = sz; setTextColor(col)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun box(color: Int = PANEL) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(16).toFloat(); setStroke(dp(1), 0x3300D4FF)
    }
    private fun btn(s: String, f: () -> Unit) = tv(s, 14f).apply {
        gravity = Gravity.CENTER; background = box(); setPadding(dp(8), dp(14), dp(8), dp(14))
        setOnClickListener { f() }
    }
    private fun lp(w: Int, hh: Int, wt: Float = 0f, top: Int = 0) =
        LinearLayout.LayoutParams(w, hh, wt).apply { topMargin = dp(top) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = Prefs(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        Notif.init(this)
        speaker = Speaker(this, p)
        brain = Brain(this, p) { startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        build()
        Sched.all(this)
        askPerms()
        syncWake()
    }

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(36), dp(18), dp(40))
        }
        root.addView(tv("J.A.R.V.I.S", 28f, CYAN, true).apply { letterSpacing = 0.3f })
        clock = tv("", 14f, DIM); root.addView(clock)
        status = tv("● ONLINE", 13f, CYAN); root.addView(status, lp(WRAP, WRAP, 0f, 6))
        orb = OrbView(this); root.addView(orb, lp(dp(230), dp(230), 0f, 8))
        reply = tv("Welcome back, Sir. Tap the microphone and speak.", 16f).apply { gravity = Gravity.CENTER }
        root.addView(reply, lp(MATCH, WRAP, 0f, 4))
        heard = tv("", 13f, DIM).apply { gravity = Gravity.CENTER }
        root.addView(heard, lp(MATCH, WRAP, 0f, 2))
        val mic = tv("🎤", 38f).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF0A3A66.toInt()); setStroke(dp(3), CYAN) }
            setOnClickListener { listen() }
        }
        root.addView(mic, lp(dp(96), dp(96), 0f, 10))

        root.addView(tv("QUICK CONTROLS", 12f, DIM).apply { letterSpacing = 0.2f }, lp(MATCH, WRAP, 0f, 18))
        val quick = listOf(
            "▶ YouTube" to "open youtube", "f Facebook" to "open facebook", "✆ WhatsApp" to "open whatsapp",
            "◉ Chrome" to "open chrome", "📷 Camera" to "open camera", "⚙ Settings" to "open settings"
        )
        for (row in quick.chunked(3)) {
            val r = LinearLayout(this)
            row.forEach { (label, cmd) ->
                r.addView(btn(label) { exec(cmd) }, lp(0, WRAP, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            root.addView(r, lp(MATCH, WRAP))
        }

        root.addView(tv("TODAY'S REMINDERS", 12f, DIM).apply { letterSpacing = 0.2f }, lp(MATCH, WRAP, 0f, 18))
        remBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(remBox, lp(MATCH, WRAP, 0f, 6))
        root.addView(btn("＋ Add reminder") { addRem() }, lp(MATCH, WRAP, 0f, 6))
        root.addView(btn("⚙ Assistant settings") { settings() }, lp(MATCH, WRAP, 0f, 10))

        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(root) })
    }

    override fun onResume() { super.onResume(); h.post(tick); refreshRem() }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
    override fun onDestroy() { sr?.destroy(); speaker.shutdown(); super.onDestroy() }

    private fun show(r: String, resumeWake: Boolean = false) {
        reply.text = r
        speaker.say(r) { if (resumeWake) runOnUiThread { syncWake() } }
    }
    private fun exec(cmd: String) = show(brain.handle(cmd))

    private fun setListening(on: Boolean) {
        orb.active = on
        if (!on) orb.level = 0f
        status.text = if (on) "● LISTENING…" else "● ONLINE"
    }

    private fun errText(e: Int) = when (e) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I did not catch that, Sir. Please try again."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is needed, Sir."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
            "The speech service needs internet or an offline language pack. Open the Google app > Settings > Voice > Offline speech recognition and download English / Bengali."
        12, 13 -> "This language is not supported by your phone's speech service, Sir."
        else -> "Speech recognition error ($e). Please try again."
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { askPerms(); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            show("Speech recognition is not available on this phone, Sir. Install or enable the Google app.")
            return
        }
        stopService(Intent(this, WakeService::class.java)) // only one app can use the microphone at a time
        sr?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : Listener() {
            override fun onReadyForSpeech(p0: Bundle?) { setListening(true) }
            override fun onRmsChanged(p0: Float) { orb.level = ((p0 + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onError(e: Int) { setListening(false); show(errText(e), true) }
            override fun onResults(b: Bundle?) {
                setListening(false)
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t == null) show(errText(SpeechRecognizer.ERROR_NO_MATCH), true)
                else { heard.text = "“$t”"; show(brain.handle(t), true) }
            }
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (p.bangla) "bn-BD" else "en-US")
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        )
    }

    private fun syncWake() {
        val i = Intent(this, WakeService::class.java)
        if (p.wake && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            try { startForegroundService(i) } catch (e: Exception) {}
        } else stopService(i)
    }

    private fun missingPerms(): List<String> {
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        return need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    }

    private fun askPerms() {
        val miss = missingPerms()
        if (miss.isNotEmpty()) requestPermissions(miss.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        syncWake()
    }

    private fun safeStart(i: Intent) {
        try { startActivity(i) } catch (e: Exception) { Toast.makeText(this, "Not available on this phone", Toast.LENGTH_SHORT).show() }
    }

    // ---------- Reminders ----------
    private fun dlg() = AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)

    private fun refreshRem() {
        remBox.removeAllViews()
        p.reminders.sortedWith(compareBy({ it.h }, { it.m })).forEach { r ->
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; background = box(); setPadding(dp(12), dp(8), dp(6), dp(8))
            }
            val time = tv(String.format(Locale.US, "%02d:%02d", r.h, r.m), 18f, CYAN, true)
            time.setOnClickListener {
                TimePickerDialog(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK, { _, hh, mm -> r.h = hh; r.m = mm; save(r) }, r.h, r.m, false).show()
            }
            val txt = tv(r.text, 13f)
            txt.setOnClickListener { editText(r) }
            val sw = Switch(this)
            sw.isChecked = r.on
            sw.setOnCheckedChangeListener { _, v -> r.on = v; save(r, false) }
            val del = tv("✕", 18f, 0xFFFF6B6B.toInt())
            del.setPadding(dp(12), 0, dp(8), 0)
            del.setOnClickListener { delRem(r) }
            row.addView(time)
            row.addView(txt, lp(0, WRAP, 1f).apply { leftMargin = dp(12) })
            row.addView(sw); row.addView(del)
            remBox.addView(row, lp(MATCH, WRAP, 0f, 6))
        }
    }

    private fun save(r: Reminder, redraw: Boolean = true) {
        p.reminders = p.reminders.map { if (it.id == r.id) r else it }
        Sched.plan(this, r)
        if (redraw) refreshRem()
    }

    private fun delRem(r: Reminder) {
        Sched.cancel(this, r)
        p.reminders = p.reminders.filter { it.id != r.id }
        refreshRem()
    }

    private fun editText(r: Reminder) {
        val et = EditText(this).apply { setText(r.text) }
        dlg().setTitle("Spoken message").setView(et)
            .setPositiveButton("Save") { _, _ -> r.text = et.text.toString().ifBlank { "Reminder" }; save(r) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun addRem() {
        TimePickerDialog(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK, { _, hh, mm ->
            val et = EditText(this).apply { hint = "Message / বার্তা"; setText("Sir, this is your reminder.") }
            dlg().setTitle("Spoken message").setView(et).setPositiveButton("Save") { _, _ ->
                val r = Reminder((System.currentTimeMillis() % 100000000).toInt() + 10, hh, mm, et.text.toString().ifBlank { "Reminder" }, true)
                p.reminders = p.reminders + r
                Sched.plan(this, r)
                refreshRem()
            }.setNegativeButton("Cancel", null).show()
        }, 8, 0, false).show()
    }

    // ---------- Settings ----------
    private fun seek(f: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) { if (u) f(v) }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    private fun settings() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(4)) }
        fun sw(label: String, v: Boolean, f: (Boolean) -> Unit) {
            val s = Switch(this)
            s.text = label; s.isChecked = v; s.setTextColor(TEXT)
            s.setOnCheckedChangeListener { _, x -> f(x) }
            col.addView(s, lp(MATCH, WRAP, 0f, 6))
        }
        sw("বাংলা (Bengali) mode", p.bangla) { p.bangla = it }
        sw("Wake word \"Hey JARVIS\" (mic service)", p.wake) { p.wake = it; syncWake() }
        sw("Remind me to resume listening after reboot", p.boot) { p.boot = it }
        col.addView(tv("Speech speed", 13f, DIM), lp(WRAP, WRAP, 0f, 10))
        col.addView(SeekBar(this).apply { max = 15; progress = ((p.rate - 0.5f) * 10).toInt(); setOnSeekBarChangeListener(seek { p.rate = 0.5f + it / 10f }) })
        col.addView(tv("Voice pitch (lower = deeper)", 13f, DIM), lp(WRAP, WRAP, 0f, 10))
        col.addView(SeekBar(this).apply { max = 10; progress = ((p.pitch - 0.5f) * 10).toInt(); setOnSeekBarChangeListener(seek { p.pitch = 0.5f + it / 10f }) })
        col.addView(btn("🔊 Test voice") {
            speaker.say(if (p.bangla) "আমি জার্ভিস, আপনার সহকারী।" else "I am JARVIS, at your service, Sir.")
        }, lp(MATCH, WRAP, 0f, 10))
        col.addView(btn("Permissions") {
            if (missingPerms().isNotEmpty()) askPerms()
            else safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, lp(MATCH, WRAP, 0f, 6))
        col.addView(btn("Battery: set JARVIS to Unrestricted") {
            Toast.makeText(this, "Open JARVIS AI > Battery > Unrestricted / Don't optimize", Toast.LENGTH_LONG).show()
            safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }, lp(MATCH, WRAP, 0f, 6))
        col.addView(btn("Allow exact alarms (for reminders)") {
            if (Build.VERSION.SDK_INT >= 31) safeStart(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
        }, lp(MATCH, WRAP, 0f, 6))
        dlg().setTitle("JARVIS settings").setView(ScrollView(this).apply { addView(col) })
            .setPositiveButton("Close", null).show()
    }
}
