package com.jarvis.ai

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Optional wake-word service. It is visible (persistent notification) and only runs when the user turns it on. */
class WakeService : Service() {
    private lateinit var p: Prefs
    private lateinit var speaker: Speaker
    private lateinit var brain: Brain
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var awaiting = false
    private var dead = false

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        p = Prefs(this)
        Notif.init(this)
        val tap = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "wake").setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("JARVIS is listening for \"Hey JARVIS\"")
            .setContentText("Tap to open. Turn it off in JARVIS settings.")
            .setContentIntent(tap).setOngoing(true).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        } catch (e: Exception) { stopSelf(); return }
        speaker = Speaker(this, p)
        brain = Brain(this, p) { launchFromBackground(it) }
        h.postDelayed({ listen() }, 1000)
    }

    // Android blocks apps from opening screens from the background, so we post a tap-to-continue notification.
    private fun launchFromBackground(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(this, (System.nanoTime() % 100000).toInt(), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        Notif.show(this, 2, "JARVIS", "Tap to continue, Sir.", pi, true)
        try { startActivity(i) } catch (e: Exception) {}
    }

    private fun listen() {
        if (dead) return
        sr?.destroy()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { stopSelf(); return }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        r.setRecognitionListener(object : Listener() {
            override fun onError(e: Int) {
                if (e == 9) { stopSelf(); return }
                awaiting = false
                h.postDelayed({ listen() }, if (e == 8) 2500L else 700L)
            }

            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase() ?: ""
                val wake = Regex("jarvis|jarvish|জার্ভিস|জারভিস|জারবিস").containsMatchIn(t)
                if (t.isNotBlank() && (awaiting || wake || brain.pending != null)) {
                    val reply = brain.handle(t)
                    awaiting = brain.expectMore
                    r.cancel()
                    speaker.say(reply) { h.post { listen() } }
                } else h.postDelayed({ listen() }, 300)
            }
        })
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (p.bangla) "bn-BD" else "en-US")
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        )
    }

    override fun onDestroy() {
        dead = true
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        if (::speaker.isInitialized) speaker.shutdown()
        super.onDestroy()
    }
}
