package com.jarvis.ai

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val p = Prefs(c)
        val r = p.reminders.firstOrNull { it.id == i.getIntExtra("id", -1) } ?: return
        Sched.plan(c, r) // schedule tomorrow's repeat
        if (!r.on) return
        val open = PendingIntent.getActivity(c, 1, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        Notif.show(c, 100 + r.id, "JARVIS", r.text, open)
        val pr = goAsync()
        val h = Handler(Looper.getMainLooper())
        var sp: Speaker? = null
        var done = false
        fun fin() { if (!done) { done = true; sp?.shutdown(); pr.finish() } }
        sp = Speaker(c.applicationContext, p) { sp?.say(r.text) { h.post { fin() } } }
        h.postDelayed({ fin() }, 25000)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Sched.all(c)
        val p = Prefs(c)
        if (p.wake && p.boot) {
            // Android does not allow starting a microphone service silently at boot, so ask the user to tap.
            val pi = PendingIntent.getActivity(c, 3, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE)
            Notif.show(c, 3, "JARVIS", "Phone restarted. Tap to resume \"Hey JARVIS\" listening.", pi)
        }
    }
}
