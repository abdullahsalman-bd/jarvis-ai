package com.jarvis.ai

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.*

data class Reminder(val id: Int, var h: Int, var m: Int, var text: String, var on: Boolean = true)

/** All settings and reminders are stored only on this phone. */
class Prefs(c: Context) {
    private val sp = c.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    var bangla: Boolean
        get() = sp.getBoolean("bn", false)
        set(v) { sp.edit().putBoolean("bn", v).apply() }
    var rate: Float
        get() = sp.getFloat("rate", 1f)
        set(v) { sp.edit().putFloat("rate", v).apply() }
    var pitch: Float
        get() = sp.getFloat("pitch", 0.75f)
        set(v) { sp.edit().putFloat("pitch", v).apply() }
    var wake: Boolean
        get() = sp.getBoolean("wake", false)
        set(v) { sp.edit().putBoolean("wake", v).apply() }
    var boot: Boolean
        get() = sp.getBoolean("boot", true)
        set(v) { sp.edit().putBoolean("boot", v).apply() }
    var reminders: List<Reminder>
        get() {
            val s = sp.getString("rem", null) ?: return defaults().also { reminders = it }
            val a = JSONArray(s)
            return (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Reminder(o.getInt("id"), o.getInt("h"), o.getInt("m"), o.getString("t"), o.getBoolean("on"))
            }
        }
        set(v) {
            val a = JSONArray()
            v.forEach { a.put(JSONObject().put("id", it.id).put("h", it.h).put("m", it.m).put("t", it.text).put("on", it.on)) }
            sp.edit().putString("rem", a.toString()).apply()
        }

    private fun defaults(): List<Reminder> {
        val d = listOf(
            Triple(7, "Good morning, Sir. I hope you slept well.", "সুপ্রভাত স্যার। আশা করি ভালো ঘুম হয়েছে।"),
            Triple(9, "Sir, it is time to drink some water.", "স্যার, পানি পান করার সময় হয়েছে।"),
            Triple(10, "Study time, Sir. Small steps every day lead to big results.", "পড়ার সময় স্যার। প্রতিদিনের ছোট পদক্ষেপই বড় সাফল্য আনে।"),
            Triple(13, "Sir, it is lunch time. Please eat something.", "স্যার, দুপুরের খাবারের সময়। কিছু খেয়ে নিন।"),
            Triple(17, "Sir, how is your study progress today?", "স্যার, আজকের পড়াশোনা কেমন এগোচ্ছে?"),
            Triple(20, "Sir, please review your day and plan tomorrow.", "স্যার, আজকের কাজের হিসাব নিন এবং আগামীকালের পরিকল্পনা করুন।"),
            Triple(22, "Sir, it is time to prepare for sleep.", "স্যার, ঘুমের প্রস্তুতি নেওয়ার সময় হয়েছে।")
        )
        return d.mapIndexed { i, t -> Reminder(i + 1, t.first, 0, if (bangla) t.third else t.second, true) }
    }
}

object Sched {
    private fun pi(c: Context, id: Int) = PendingIntent.getBroadcast(
        c, id, Intent(c, ReminderReceiver::class.java).putExtra("id", id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun all(c: Context) = Prefs(c).reminders.forEach { plan(c, it) }

    fun cancel(c: Context, r: Reminder) {
        c.getSystemService(AlarmManager::class.java).cancel(pi(c, r.id))
    }

    fun plan(c: Context, r: Reminder) {
        val am = c.getSystemService(AlarmManager::class.java)
        am.cancel(pi(c, r.id))
        if (!r.on) return
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, r.h); cal.set(Calendar.MINUTE, r.m)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis() + 1000) cal.add(Calendar.DAY_OF_YEAR, 1)
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi(c, r.id))
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi(c, r.id))
    }
}

object Notif {
    fun init(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("wake", "JARVIS listening", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("alert", "JARVIS reminders", NotificationManager.IMPORTANCE_HIGH))
    }

    fun show(c: Context, id: Int, title: String, text: String, pi: PendingIntent? = null, full: Boolean = false) {
        init(c)
        val b = Notification.Builder(c, "alert").setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title).setContentText(text).setAutoCancel(true)
        if (pi != null) {
            b.setContentIntent(pi)
            if (full) b.setFullScreenIntent(pi, true)
        }
        try { c.getSystemService(NotificationManager::class.java).notify(id, b.build()) } catch (e: Exception) {}
    }
}

/** Android built-in Text-to-Speech. Picks a male-named voice if the phone has one; otherwise uses a lower pitch. */
class Speaker(private val ctx: Context, private val prefs: Prefs, onReady: () -> Unit = {}) {
    private var tts: TextToSpeech? = null
    private var ready = false

    init {
        tts = TextToSpeech(ctx.applicationContext) { s ->
            ready = s == TextToSpeech.SUCCESS
            onReady()
        }
    }

    fun say(text: String, onDone: (() -> Unit)? = null) {
        val t = tts
        if (t == null || !ready) { onDone?.invoke(); return }
        val bn = text.any { it in '\u0980'..'\u09FF' }
        val loc = if (bn) Locale("bn", "BD") else Locale.US
        if (t.isLanguageAvailable(loc) < TextToSpeech.LANG_AVAILABLE) {
            t.language = Locale.US
        } else {
            t.language = loc
            try {
                t.voices?.firstOrNull {
                    it.locale.language == loc.language && it.name.contains("male", true) &&
                        !it.name.contains("female", true) && !it.isNetworkConnectionRequired
                }?.let { t.voice = it }
            } catch (e: Exception) {}
        }
        t.setSpeechRate(prefs.rate)
        t.setPitch(prefs.pitch)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { onDone?.invoke() }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { onDone?.invoke() }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    fun shutdown() { tts?.stop(); tts?.shutdown(); tts = null }
}

abstract class Listener : RecognitionListener {
    override fun onReadyForSpeech(p0: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(p0: Float) {}
    override fun onBufferReceived(p0: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(p0: Bundle?) {}
    override fun onEvent(p0: Int, p1: Bundle?) {}
}

/** Simple offline command matcher (English + Bengali). It is NOT a chatbot. */
class Brain(private val c: Context, private val p: Prefs, private val go: (Intent) -> Unit) {
    var pending: (() -> String)? = null
    var expectMore = false
    private val digits = "০১২৩৪৫৬৭৮৯"
    private val stop = setOf(
        "call", "dial", "phone", "please", "to", "send", "sms", "message", "a", "text", "hey", "jarvis", "me", "can", "you",
        "কল", "ফোন", "ডায়াল", "করো", "করুন", "কর", "দাও", "কে", "মেসেজ", "এসএমএস", "টেক্সট", "পাঠাও", "জার্ভিস", "হে"
    )

    private fun nameFrom(t: String) = t.split(Regex("\\s+"))
        .filter { it.isNotBlank() && it !in stop }
        .map { if (it.endsWith("কে") && it.length > 3) it.dropLast(2) else it }
        .joinToString(" ")

    private fun find(name: String): Pair<String, String>? {
        val ph = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val cur = c.contentResolver.query(
            ph, arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        ) ?: return null
        cur.use { return if (it.moveToFirst()) it.getString(0) to it.getString(1) else null }
    }

    private fun parseTime(t: String): Pair<Int, Int>? {
        val mt = Regex("(\\d{1,2})(?:[:.](\\d{2}))?\\s*(am|pm|এএম|পিএম)?").find(t) ?: return null
        var h = mt.groupValues[1].toInt()
        val mi = mt.groupValues[2].ifEmpty { "0" }.toInt()
        val ap = mt.groupValues[3]
        val pm = ap == "pm" || ap == "পিএম" || Regex("বিকাল|বিকেল|সন্ধ্যা|রাত|দুপুর").containsMatchIn(t)
        val am = ap == "am" || ap == "এএম" || t.contains("সকাল")
        if (pm && h < 12) h += 12
        if (am && h == 12) h = 0
        if (t.contains("রাত") && h == 12) h = 0
        if (h > 23 || mi > 59) return null
        return h to mi
    }

    fun handle(raw: String): String {
        expectMore = false
        var t = raw.lowercase(Locale.ROOT).trim()
        t = t.map { val i = digits.indexOf(it); if (i >= 0) '0' + i else it }.joinToString("")
        val bn = p.bangla || raw.any { it in '\u0980'..'\u09FF' }
        fun m(en: String, b: String) = if (bn) b else en
        fun has(vararg k: String) = k.any { t.contains(it) }
        fun open(i: Intent, ok: String): String = try {
            go(i); ok
        } catch (e: Exception) {
            m("Sorry, Sir. I could not do that on this phone.", "দুঃখিত স্যার, এটা এই ফোনে করতে পারলাম না।")
        }

        pending?.let { act ->
            pending = null
            return if (has("yes", "yeah", "sure", "ok", "confirm", "হ্যাঁ", "হ্যা", "জি", "ঠিক আছে")) act()
            else m("Cancelled, Sir.", "ঠিক আছে স্যার, বাতিল করলাম।")
        }

        val core = t.replace(Regex("hey|hi|hello|jarvis|জার্ভিস|জারভিস|হে|হ্যালো"), "").replace(Regex("[,.!?\\s]+"), " ").trim()
        if (core.isEmpty()) {
            expectMore = true
            return m("Yes, Sir. How may I assist you?", "জি স্যার, কীভাবে সাহায্য করতে পারি?")
        }

        if (has("speak english", "english mode", "ইংরেজিতে")) { p.bangla = false; return "Switching to English, Sir." }
        if (has("speak bengali", "bengali mode", "বাংলায় কথা")) { p.bangla = true; return "ঠিক আছে স্যার, এখন থেকে বাংলায় কথা বলব।" }

        if (has("alarm", "অ্যালার্ম", "এলার্ম", "আলার্ম")) {
            val tm = parseTime(t) ?: return m("What time should I set the alarm for, Sir?", "কয়টায় অ্যালার্ম দেব স্যার?")
            val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, tm.first)
                .putExtra(AlarmClock.EXTRA_MINUTES, tm.second).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            val hm = String.format(Locale.US, "%02d:%02d", tm.first, tm.second)
            return open(i, m("Alarm set for $hm, Sir.", "$hm এর জন্য অ্যালার্ম সেট করলাম স্যার।"))
        }

        if (has("remind", "মনে করিয়ে", "রিমাইন্ড")) {
            val tm = parseTime(t) ?: return m(
                "At what time, Sir? For example: remind me to study at 8 PM.",
                "কোন সময়ে স্যার? যেমন: রাত ৮টায় পড়তে মনে করিয়ে দাও।"
            )
            val what = Regex("remind me to (.+?)(?: at | by |$)").find(t)?.groupValues?.get(1)?.trim()
                ?.takeIf { it.isNotEmpty() } ?: raw
            val r = Reminder((System.currentTimeMillis() % 100000000).toInt() + 10, tm.first, tm.second, what, true)
            p.reminders = p.reminders + r
            Sched.plan(c, r)
            return m("Certainly, Sir. Your reminder has been saved.", "অবশ্যই স্যার, আপনার রিমাইন্ডার সেভ করা হয়েছে।")
        }

        if (has("call", "dial", "কল", "ফোন করো", "ফোন কর")) {
            val name = nameFrom(t)
            if (name.isEmpty()) return m("Whom should I call, Sir?", "কাকে কল করব স্যার?")
            val num: String
            val label: String
            if (name.all { it.isDigit() || it == '+' }) { num = name; label = name }
            else {
                if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
                    return m("I need contacts permission, Sir. Please allow it in JARVIS settings.", "স্যার, কন্টাক্ট পারমিশন দরকার। JARVIS সেটিংস থেকে অনুমতি দিন।")
                val f = find(name) ?: return m("I could not find $name in your contacts.", "কন্টাক্টে $name নামে কাউকে পাইনি।")
                label = f.first; num = f.second
            }
            pending = {
                val perm = c.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                open(
                    Intent(if (perm) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))),
                    m("Calling $label.", "$label কে কল করছি।")
                )
            }
            expectMore = true
            return m("Shall I call $label, Sir? Say yes to confirm.", "$label কে কল করব স্যার? নিশ্চিত করতে 'হ্যাঁ' বলুন।")
        }

        if (has("sms", "message", "মেসেজ", "এসএমএস", "টেক্সট")) {
            val name = nameFrom(t)
            if (name.isEmpty()) return m("Whom should I message, Sir?", "কাকে মেসেজ করব স্যার?")
            val num: String
            val label: String
            if (name.all { it.isDigit() || it == '+' }) { num = name; label = name }
            else {
                if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
                    return m("I need contacts permission, Sir.", "স্যার, কন্টাক্ট পারমিশন দরকার।")
                val f = find(name) ?: return m("I could not find $name in your contacts.", "কন্টাক্টে $name নামে কাউকে পাইনি।")
                label = f.first; num = f.second
            }
            return open(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num))),
                m("Opening a message to $label.", "$label এর জন্য মেসেজ খুলছি।"))
        }

        if (has("open", "launch", "start", "খুল", "খোল", "ওপেন", "চালু", "চালাও")) {
            if (has("camera", "ক্যামেরা")) return open(Intent(MediaStore.ACTION_IMAGE_CAPTURE), m("Opening the camera, Sir.", "ক্যামেরা খুলছি স্যার।"))
            val screens = mapOf(
                "wifi" to Settings.ACTION_WIFI_SETTINGS, "wi-fi" to Settings.ACTION_WIFI_SETTINGS, "ওয়াইফাই" to Settings.ACTION_WIFI_SETTINGS,
                "bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS, "ব্লুটুথ" to Settings.ACTION_BLUETOOTH_SETTINGS,
                "display" to Settings.ACTION_DISPLAY_SETTINGS, "brightness" to Settings.ACTION_DISPLAY_SETTINGS, "ডিসপ্লে" to Settings.ACTION_DISPLAY_SETTINGS,
                "sound" to Settings.ACTION_SOUND_SETTINGS, "volume" to Settings.ACTION_SOUND_SETTINGS, "সাউন্ড" to Settings.ACTION_SOUND_SETTINGS,
                "battery" to Settings.ACTION_BATTERY_SAVER_SETTINGS, "ব্যাটারি" to Settings.ACTION_BATTERY_SAVER_SETTINGS,
                "location" to Settings.ACTION_LOCATION_SOURCE_SETTINGS, "লোকেশন" to Settings.ACTION_LOCATION_SOURCE_SETTINGS,
                "airplane" to Settings.ACTION_AIRPLANE_MODE_SETTINGS, "এয়ারপ্লেন" to Settings.ACTION_AIRPLANE_MODE_SETTINGS
            )
            screens.entries.firstOrNull { t.contains(it.key) }?.let {
                return open(Intent(it.value), m("Opening that settings screen, Sir.", "সেটিংস স্ক্রিন খুলছি স্যার।"))
            }
            if (has("setting", "সেটিং")) return open(Intent(Settings.ACTION_SETTINGS), m("Opening settings, Sir.", "সেটিংস খুলছি স্যার।"))
            val known = listOf(
                Triple(listOf("youtube", "ইউটিউব"), "com.google.android.youtube", "https://m.youtube.com"),
                Triple(listOf("facebook", "ফেসবুক"), "com.facebook.katana", "https://m.facebook.com"),
                Triple(listOf("whatsapp", "হোয়াটসঅ্যাপ", "হোয়াটসআপ", "হোয়াটস অ্যাপ"), "com.whatsapp", "https://web.whatsapp.com"),
                Triple(listOf("chrome", "ক্রোম"), "com.android.chrome", "https://www.google.com")
            )
            known.firstOrNull { k -> has(*k.first.toTypedArray()) }?.let { k ->
                val name = k.first[0].replaceFirstChar { it.uppercase() }
                val li = c.packageManager.getLaunchIntentForPackage(k.second) ?: Intent(Intent.ACTION_VIEW, Uri.parse(k.third))
                return open(li, m("Opening $name, Sir.", "$name খুলছি স্যার।"))
            }
            val pm = c.packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val hit = apps.firstOrNull { val l = it.loadLabel(pm).toString().lowercase(); l.length > 1 && t.contains(l) }
            val li = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            if (li != null) return open(li, m("Opening ${hit.loadLabel(pm)}, Sir.", "${hit.loadLabel(pm)} খুলছি স্যার।"))
            return m("I could not find that application, Sir.", "অ্যাপটি খুঁজে পাইনি স্যার।")
        }

        if (has("time", "সময়", "কয়টা", "কটা")) {
            val s = java.text.SimpleDateFormat("h:mm a", Locale(if (bn) "bn" else "en")).format(Date())
            return m("It is $s, Sir.", "এখন সময় $s স্যার।")
        }
        if (has("date", "তারিখ", "what day", "কি বার", "কী বার")) {
            val s = java.text.SimpleDateFormat("EEEE, d MMMM yyyy", Locale(if (bn) "bn" else "en")).format(Date())
            return m("Today is $s, Sir.", "আজ $s স্যার।")
        }
        if (has("lazy", "tired", "bored", "আলসেমি", "অলস", "ক্লান্ত"))
            return m("Let's get started, Sir. Even 20 minutes of focused study is progress.", "চলুন শুরু করি স্যার। মাত্র ২০ মিনিট মনোযোগ দিয়ে পড়লেও সেটা অগ্রগতি।")
        if (has("good morning", "সুপ্রভাত")) return m("Good morning, Sir. Ready when you are.", "সুপ্রভাত স্যার। আমি প্রস্তুত।")
        if (has("thank", "ধন্যবাদ")) return m("You are welcome, Sir.", "আপনাকে স্বাগতম স্যার।")
        if (has("who are you", "তুমি কে", "আপনি কে"))
            return m("I am JARVIS, your personal assistant. I understand fixed commands, I am not a chatbot, Sir.", "আমি জার্ভিস, আপনার ব্যক্তিগত সহকারী। আমি নির্দিষ্ট কমান্ড বুঝি, চ্যাটবট নই স্যার।")
        if (has("help", "সাহায্য"))
            return m("I can open apps, call contacts, open SMS, set alarms and reminders, and tell the time and date.", "আমি অ্যাপ খুলতে, কল ও মেসেজ করতে, অ্যালার্ম ও রিমাইন্ডার দিতে এবং সময়-তারিখ বলতে পারি।")
        return m("Sorry, Sir. I did not understand. Say help to hear what I can do.", "দুঃখিত স্যার, বুঝতে পারিনি। আমি কী পারি জানতে 'সাহায্য' বলুন।")
    }
}
